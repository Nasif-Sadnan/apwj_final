package com.Assignment2.SuperShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
